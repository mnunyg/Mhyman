# Telegram GPT Bot
This is a simple Telegram bot using GPT-3.5.